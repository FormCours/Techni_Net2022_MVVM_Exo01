﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Tools.MVVM.Commands;
using Tools.MVVM.ViewModels;

namespace Techni_Net2022_MVVM_Exo01.ViewModels
{
    internal class MainViewModel : ViewModelBase
    {
        #region Fields
        private int _Speed;
        private bool _IsStart;
        private List<string> _LogEvents;

        private IRelayCommand? _StartCommand;
        private IRelayCommand? _SpeedUpCommand;
        private IRelayCommand? _SpeedDownCommand;
        private IRelayCommand? _TurnLeftCommand;
        private IRelayCommand? _TurnRightCommand;
        #endregion

        public MainViewModel()
        {
            _LogEvents = new List<string>();
            _LogEvents.Add("Start Simulation !");
        }

        #region Properties
        public int Speed
        {
            get { return _Speed; }
            set 
            { 
                _Speed = value;
                RaisePropertyChanged();
            }
        }
        public bool IsStart
        {
            get { return _IsStart; }
            set 
            { 
                _IsStart = value;
                RaisePropertyChanged();
            }
        }
        public List<string> LogEvent
        {
            get { return _LogEvents; }
        }
        #endregion

        #region RelayCommand
        public IRelayCommand StartCommand
        {
            get { return _StartCommand ?? (_StartCommand = new RelayCommand(EngineSwitch)); }
        }
        public IRelayCommand SpeedUpCommand
        {
            get { return _SpeedUpCommand ?? (_SpeedUpCommand = new RelayCommand(SpeedUp, CheckEngineStart)); }
        }
        public IRelayCommand SpeedDownCommand
        {
            get { return _SpeedDownCommand ?? (_SpeedDownCommand = new RelayCommand(SpeedDown, CheckEngineStart)); }
        }
        public IRelayCommand TurnLeftCommand
        {
            get { return _TurnLeftCommand ?? (_TurnLeftCommand = new RelayCommand(TurnLeft, CheckEnableTurn)); }
        }
        public IRelayCommand TurnRightCommand
        {
            get { return _TurnRightCommand ?? (_TurnRightCommand = new RelayCommand(TurnRight, CheckEnableTurn)); }
        }
        #endregion

        #region Methods
        private void EngineSwitch()
        {
            IsStart = !IsStart;

            LogEvent.Add(IsStart ? "Demarrage du moteur" : "Arrêt du moteur");
        }

        private void SpeedUp()
        {
            Speed += 10;

            LogEvent.Add("Le vehicule accélére");
        }

        private void SpeedDown()
        {
            if(Speed > 0)
            {
                Speed -= 10;

                LogEvent.Add("Le vehicule decélére");
            }
            else
            {
                LogEvent.Add("Le vehicule est a l'arrêt");
            }
        }

        private void TurnLeft()
        {
            LogEvent.Add("Le vehicule tourne à gauche");
        }

        private void TurnRight()
        {
            LogEvent.Add("Le vehicule tourne à droite");
        }

        private bool CheckEngineStart()
        {
            return IsStart;
        }

        private bool CheckEnableTurn()
        {
            return CheckEngineStart() && Speed > 0;
        }
        #endregion
    }
}
