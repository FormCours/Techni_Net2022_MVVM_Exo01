﻿using System;

namespace Tools.MVVM.Converters
{
    public class ConverterBase : IValueConverter
    {
    }
}
